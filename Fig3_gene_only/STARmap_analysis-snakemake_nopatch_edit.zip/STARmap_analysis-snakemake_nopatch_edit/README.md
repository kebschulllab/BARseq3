# Get Started - Running Pipeline on HPC (Using Snakemake)

## First, clone this repository
clone the code under this branch:
<code>git clone --single-branch --branch snakemake https://github.com/mmganant/STARmap_analysis.git</code>

## Next, activate the Conda environment
### Create environment, if not already created
- use environment *starmap*: <code>conda create -n starmap python==3.9.2</code>
- activate the environment: <code>conda activate starmap</code>
- make sure CUDA, CUDNN, and NVIDIA/GPU Drivers are properly installed
- install tensorflow based on the system: https://www.tensorflow.org/install/pip (you may need to downgrade Numpy version)
   - this should be tensorflow version 2.18.0 on Rockfish!!
- install bardensr dependency: <code>pip install --upgrade git+https://github.com/jacksonloper/bardensr.git</code>
- **note: you must have CUDA properly downloaded and enabled for fast GPU processing
- install additional dependencies: <code>pip install n2v scanpy anndata cellpose pims-nd2 ipython imagej napari SimpleITK</code>
- pip install snakemake
- pip install pulp==2.5.1

## Each time you login into Rockfish, you need to activate the following modules and activate the environment in this order:
1. <code>module load anaconda</code>
2. <code>conda activate starmap</code>
3. <code>module load cuda/12.5.0 cudnn/9.2.0</code>

## Then, modify the configurations for your dataset/filepaths/etc
- navigate to the folder containing the "config.json" document
- type <code>vi config.json</code> into the terminal to activate the text editor
- press <code>i</code> to insert text and change the configurations at the top of the file
- press <code>Esc</code>, then <code>wq!</code> to write the changes to the document

## Run the pipeline

- run <code>nohup snakemake --slurm --jobs   "$(python -c 'import h5py; f=h5py.File("image_origin.hdf5","r"); print(int(len(f["list"])))')"   -s Snakefile_nopatch   --profile profile   --latency-wait 300   --rerun-incomplete   > snakemake_output.log 2>&1 &</code>
- or run <code>./run_starmap_snakemake_nohup.sh</code>
- this will write the output log to snakemake_output.log ... you can look at this log by typing <code>cat snakemake_output.log</code>
- A SLURM job can be started with <code>sbatch slurm_snakemake_arg.slurm.script</code> after editing the SLURM script to point to your data.
- And a directory argument can be passed to a SLURM script using <code>sbatch --export=section=SECTION_NAME slurm_snakemake_arg.slurm.script</code>

# File Hierarchies

## Run the script
necessary files for running the pipeline:  

└── ~~ data path (entered by user during configuration) ~~  
&emsp;&emsp;├── image_origin.hdf5           

&emsp;&emsp;├── codebook.csv  * can be named something else - must specify during config

&emsp;&emsp;├── dapi_all_z.npy 

&emsp;&emsp;├── positions_org.csv     

&emsp;&emsp;├── output/       * output created in the same folder

&emsp;&emsp;&emsp;&emsp;├── adata.h5ad


## Notes for config
|variables           |notes                                          |
| ------------------ | --------------------------------------------- |
|**path**|path to where output file is created|
|**gtca_path**|path to where image_origin.hdf5 is stored|
|**dapi_path**|path to where dapi_all_z is stored|
|**positions_path**|path to where positions are stored (*.csv)|
|**codebook_path**|path to where codebook is stored (*.csv)|
|**FOVs**|range of field of views|
|**FOV_minmax**|field of views used for computing min/max and find threshold|
|**filepath_dapi**|path to dapi img|
|**radius**|radius of background subtraction|
|**max_wiggle**|maximum displacement with bardensr registration|
|**niter**|number of iterations bardensr registration|
|**round_num**|total rounds [1 ,2 ,3, 4, 5, 6] start from 1 :exclamation: should include more than one round|
|**fov_align**|field of view used to perform channel alignment correction - change to field of view with as many dots as possible|
|cc_coeff|[zero_one, one_zero, two_three, three_two]|
|**fov_minmax**|specify the fovs for calculating the minimum and maximum values|
|radius|set the radius of background subtraction (larger -> less background subtracted)|
|base_code|the list of base in codebook|
|**thresh_refined**|threshold used for calling genes if find_threshold = False|
|**find_threshold**|find threshold (True) or use thresh_refined (False)|
|**precision**|precision of threshold if find_threshold = True|


example:
path = "ma31_e13_b5/" #(Snakefile path)
gtca_path = path + "" #image_origin.hdf5
dapi_path = path + "" # dapi_all_z.npy
codebook_path = path + "CAMs_TFs_barcodes_final_8nogene_spikein.csv"
positions_path = path + "position_org.csv"
positions_glob = positions_path


FOVs = range(35)
FOV_minmax = np.array([10,20,5,7,17])
fov_align = 7
radius = 10
max_wiggle = 15
niter = 80
round_num =  [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
noisefloor = 0.05,
len_wid = 1000,
base_code = ["G", "T", "C", "A"]
fdr_thresh = 0.2
nogene_keyword = "no_gene"
thresh_refined = 0.75,
find_threshold = False
precision = 0.005
