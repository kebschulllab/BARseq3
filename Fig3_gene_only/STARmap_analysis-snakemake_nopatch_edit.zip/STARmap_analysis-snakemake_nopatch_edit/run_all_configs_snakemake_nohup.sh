#!/bin/bash

# Directory containing JSON config files
config_dir="/home/cworkma5/scratch4-jkebsch1/chris/younglc24_aged_lc05/configs/"  # Replace with the path to your config directory

# Loop through each JSON config file in the directory
for config_file in "$config_dir"/*.json; do
    echo "Processing config: $config_file"

    # Extract values from the JSON file
    data_path=$(grep '"path"' "$config_file" | sed 's/.*: "\(.*\)",/\1/')
    gtca_path=$(grep '"gtca_path"' "$config_file" | sed 's/.*: "\(.*\)",/\1/')
    section=$(grep '"section"' "$config_file" | sed 's/.*: "\(.*\)",/\1/')

    # Concatenate data_path and gtca_path
    full_gtca_path="${data_path}${gtca_path}"

    # Copy Snakemake file to data_path
    cp Snakefile_nopatch "$data_path"

    # Use the concatenated path in the Snakemake command
    nohup snakemake --slurm --jobs "$(python -c "import h5py; f=h5py.File('$full_gtca_path', 'r'); print(int(len(f['list'])))")" \
       -s "$data_path"Snakefile_nopatch \
       --configfile "$config_dir$config_file" \
       --directory "$data_path" \
       --profile profile \
       --latency-wait 300 \
       --rerun-incomplete > "${data_path}/snakemake_output_${section}.log" 2>&1 &

    echo "Snakemake launched for section: $section"
done

echo "All configurations processed."
