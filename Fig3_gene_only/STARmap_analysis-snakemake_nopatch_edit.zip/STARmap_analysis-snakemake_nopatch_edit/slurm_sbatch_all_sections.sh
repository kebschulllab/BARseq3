#!/bin/bash

# Directory containing JSON config files
config_dir="/home/cworkma5/scratch4-jkebsch1/chris/younglc24_aged_lc05/configs/"

# Loop through each JSON config file
for config_file in "$config_dir"*.json; do
    # Extract the section name from the config file name
    section=$(basename "$config_file" .json | sed 's/config_//')

    # Submit the SLURM script for this section
    echo "Submitting job for section: $section"
    sbatch --export=section=$section slurm_snakemake_arg.slurm.script
done

echo "All jobs submitted."